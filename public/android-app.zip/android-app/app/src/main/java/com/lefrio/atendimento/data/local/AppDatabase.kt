package com.lefrio.atendimento.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.lefrio.atendimento.data.local.dao.EquipmentChecklistDao
import com.lefrio.atendimento.data.local.dao.RouteExpenseDao
import com.lefrio.atendimento.data.local.dao.ServiceOrderDao
import com.lefrio.atendimento.data.local.dao.SyncQueueDao
import com.lefrio.atendimento.data.local.dao.TechNotificationDao
import com.lefrio.atendimento.data.local.dao.TechnicianDao
import com.lefrio.atendimento.data.local.entity.EquipmentChecklistEntity
import com.lefrio.atendimento.data.local.entity.RouteExpenseEntity
import com.lefrio.atendimento.data.local.entity.ServiceOrderEntity
import com.lefrio.atendimento.data.local.entity.SyncQueueEntity
import com.lefrio.atendimento.data.local.entity.TechNotificationEntity
import com.lefrio.atendimento.data.local.entity.TechnicianEntity

@Database(
    entities = [
        ServiceOrderEntity::class,
        EquipmentChecklistEntity::class,
        SyncQueueEntity::class,
        RouteExpenseEntity::class,
        TechNotificationEntity::class,
        TechnicianEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun serviceOrderDao(): ServiceOrderDao
    abstract fun equipmentChecklistDao(): EquipmentChecklistDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun routeExpenseDao(): RouteExpenseDao
    abstract fun techNotificationDao(): TechNotificationDao
    abstract fun technicianDao(): TechnicianDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lefrio_atendimento.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
