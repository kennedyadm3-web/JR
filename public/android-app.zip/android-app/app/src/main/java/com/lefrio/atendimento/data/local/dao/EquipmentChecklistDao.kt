package com.lefrio.atendimento.data.local.dao

import androidx.room.*
import com.lefrio.atendimento.data.local.entity.EquipmentChecklistEntity
import kotlinx.coroutines.flow.Flow

data class OrderChecklistProgress(
    val orderId: String,
    val totalCount: Int,
    val completedCount: Int
)

data class AddressEquipmentResult(
    val id: String,
    val name: String,
    val brand: String? = null,
    val btu: String? = null,
    val sector: String? = null,
    val addressId: String? = null
)

@Dao
interface EquipmentChecklistDao {

    @Query("""
        SELECT DISTINCT ec.equipmentId as id, ec.equipmentName as name, ec.equipmentBrand as brand, ec.equipmentBtus as btu, ec.equipmentSector as sector, so.addressId as addressId
        FROM equipment_checklists ec
        INNER JOIN service_orders so ON ec.orderId = so.id
        WHERE TRIM(so.addressId) = TRIM(:addressId) OR so.addressId LIKE '%' || :addressId || '%'
        ORDER BY ec.equipmentName ASC
    """)
    suspend fun getDistinctEquipmentsForAddress(addressId: String): List<AddressEquipmentResult>

    @Query("""
        SELECT DISTINCT ec.equipmentId as id, ec.equipmentName as name, ec.equipmentBrand as brand, ec.equipmentBtus as btu, ec.equipmentSector as sector, so.addressId as addressId
        FROM equipment_checklists ec
        INNER JOIN service_orders so ON ec.orderId = so.id
        ORDER BY ec.equipmentName ASC
    """)
    suspend fun getDistinctEquipmentsAll(): List<AddressEquipmentResult>

    @Query("""
        SELECT 
            orderId, 
            COUNT(*) as totalCount, 
            SUM(CASE WHEN isChecked = 1 OR isSkipped = 1 THEN 1 ELSE 0 END) as completedCount 
        FROM equipment_checklists 
        GROUP BY orderId
    """)
    fun getAllOrdersProgressFlow(): Flow<List<OrderChecklistProgress>>

    @Query("SELECT * FROM equipment_checklists WHERE orderId = :orderId ORDER BY equipmentName ASC")
    fun getChecklistForOrderFlow(orderId: String): Flow<List<EquipmentChecklistEntity>>

    @Query("SELECT * FROM equipment_checklists WHERE orderId = :orderId")
    suspend fun getChecklistForOrder(orderId: String): List<EquipmentChecklistEntity>

    @Query("SELECT * FROM equipment_checklists")
    suspend fun getAllChecklists(): List<EquipmentChecklistEntity>

    @Query("SELECT * FROM equipment_checklists WHERE id = :id LIMIT 1")
    suspend fun getChecklistById(id: String): EquipmentChecklistEntity?

    @Query("SELECT * FROM equipment_checklists WHERE orderId = :orderId AND equipmentId = :equipmentId LIMIT 1")
    suspend fun getChecklistByOrderAndEquipment(orderId: String, equipmentId: String): EquipmentChecklistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: EquipmentChecklistEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<EquipmentChecklistEntity>)

    @Query("""
        UPDATE equipment_checklists SET 
            isChecked = :isChecked,
            isSkipped = :isSkipped,
            notes = :notes,
            justification = :justification,
            checkedAt = :checkedAt,
            localPhotoPathsJson = :localPhotoPathsJson,
            isSynced = 0,
            updatedAt = :timestamp
        WHERE id = :id
    """)
    suspend fun updateChecklistExecution(
        id: String,
        isChecked: Boolean,
        isSkipped: Boolean,
        notes: String,
        justification: String?,
        checkedAt: String?,
        localPhotoPathsJson: String,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE equipment_checklists SET remotePhotoUrlsJson = :remoteUrlsJson, isSynced = 1 WHERE id = :id")
    suspend fun markPhotosUploaded(id: String, remoteUrlsJson: String)

    @Query("UPDATE equipment_checklists SET isSynced = 1 WHERE id = :id")
    suspend fun markAsSynced(id: String)

    @Query("""
        DELETE FROM equipment_checklists 
        WHERE orderId IN ('PREV_CORREIOS_ANADIA', 'PREV_BB_CENTRO', 'OS_CORRETIVA_1042', 'PREV_HOSPITAL_METRO', 'OS_CORRETIVA_1055')
    """)
    suspend fun deleteFakeSeedChecklists()
}
